import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            String address = "localhost";
            int port = 150;
            Socket socket = new Socket(address, port);
            System.out.println("Client: connected to the server at " + address + " on port " + port + ".");

            // the socket's byte stream is wrapped inside an InputStream Reader which allows for characters
            // this is then wrapped inside a BufferedReader to allow cached chunks to be read
            BufferedReader in = new BufferedReader(new InputStreamReader( socket.getInputStream()));

            // PrintWriter wraps around the socket's OutputStream to allow for easily writing human-readable Strings
            // to the OutputStream
            PrintWriter out = new PrintWriter(socket.getOutputStream());

            // Scanner is used to collect user input
            Scanner scanner = new Scanner(System.in);
            String input = scanner.nextLine();

            // if the input != "QUIT", send to server
            // the server will verify the authenticity of the command and respond accordingly
            while (!input.equals("QUIT")) {
                out.println(input);
                out.flush();

                System.out.println("Client: sent " + input + " to server.");

                // when a response is received print it to the console
                System.out.println("Client: received message from server: '" + in.readLine() + "'.");

                input = scanner.nextLine();
            }

            // when client has QUIT, close the streams and socket
            in.close();
            out.close();
            socket.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
