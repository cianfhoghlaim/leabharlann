import com.sun.source.tree.SynchronizedTree;
import networking.SimpleSocketServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.Scanner;
import java.util.SortedSet;
import java.util.TreeSet;

public class Server extends Thread {
    private final int PORT;
    private final int TOKENCAPACITY = 10; // total amount of tokens server should hold
    private ServerSocket serverSocket;
    private boolean running;
    private SortedSet<String> tokens;
    private int clientID; // keeps track of how many clients have connected to the server


    // used to instantiate the server for the assignment
    public static void main(String[] args) {
        Server server = new Server(150);
        server.startServer();
    }


    public Server(int port) {
        this.PORT = port;
        tokens = Collections.synchronizedSortedSet(new TreeSet<String>());
        // returns a synchronised sorted set backed by the specified sorted set
        // in this case a TreeSet is used, which is automatically sorted lexicographically
        // and does not allow duplicates
    }

    public void startServer() {
        running = true;
        try {
            serverSocket = new ServerSocket(PORT);
            this.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        while (running) {
            try {
                System.out.println("Server: Awaiting connection from a client.");

                // Look for connection from a new client
                Socket client = serverSocket.accept();

                // Assign the new client to its own ClientHandler thread
                // use parameterised constructor to pass the client socket
                ClientHandler clientHandler = new ClientHandler(client);
                clientHandler.start();
                System.out.println("Server: Client " + clientHandler.id + " connected.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // ClientHandler is a subclass as it is only ever used by Server
    class ClientHandler extends Thread {
        private Socket clientSocket;
        private int id;

        ClientHandler(Socket socket) {
            this.clientSocket = socket;
            this.id = ++clientID; // increment to identify subsequent clients
        }

        public void run() {
            try {

                // the clientSocket's byte stream is wrapped inside an InputStream Reader which allows for characters
                // this is then wrapped inside a BufferedReader to allow cached chunks to be read
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                // PrintWriter wraps around the socket's OutputStream to allow for easily writing human-readable Strings
                // to the OutputStream
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream());

                // repeat while socket is open
                while (!clientSocket.isClosed()) {
                    // repeat while BufferedReader has information to be read
                    while (in.ready()) {
                        String received = in.readLine();
                        System.out.println("Server: Received message from Client " + clientID + ": '" + received + "'" +
                                ".");

                        // instantiate a Scanner on the received string to parse the command and token
                        Scanner scanner = new Scanner(received);

                        // default delimiter is " ", command is therefore the first word of the received String
                        String command = scanner.next();

                        String response = "";

                        // identify the command received
                        if (command.equals("RETRIEVE")) {
                            response = tokens.toString();
                        } else if (command.equals("SUBMIT") && scanner.hasNext()) {

                            if (tokens.size() == TOKENCAPACITY) {
                                response = "ERROR: Maximum capacity of " + TOKENCAPACITY + " has been reached.";
                            } else {
                                String token = scanner.next();

                                // if there is space server will attempt to add token
                                // Set's add method will check if token is already present, and skip adding if present
                                tokens.add(token);

                                // response is "OK" whether token is already present or was newly added, as required
                                response = "OK";
                            }

                        } else {
                            // if command != "RETRIEVE" || "SUBMIT" returns "ERROR"
                            // also if !scanner.hasNext() then incorrect SUBMIT usage, skips to responding "ERROR"
                            response = "ERROR";
                        }
                        out.println(response);
                        out.flush();
                        System.out.println("Server: sent response '" + response + "' to Client " + clientID);
                    }
                }
            } catch(IOException e){
                    e.printStackTrace();
            }
        }
    }
}
